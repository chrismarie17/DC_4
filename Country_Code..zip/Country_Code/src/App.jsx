// src/App.js

// eslint-disable-next-line no-unused-vars
import React from "react";
import Dropdown from "./components/Dropdown"; // Import the component
import 'bootstrap/dist/css/bootstrap.min.css';


function App() {
  return (
    <div className="App">
      <Dropdown /> {/* Use the component here */}
    </div>
  );
}

export default App;