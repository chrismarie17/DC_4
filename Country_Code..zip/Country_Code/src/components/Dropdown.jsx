// eslint-disable-next-line no-unused-vars
import React, { useState, useEffect } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';


const CountryCodeDropdown = () => {
  const [countries, setCountries] = useState([]);
  const [selectedCountry, setSelectedCountry] = useState("");
  const [locationInfo, setLocationInfo] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    async function loadCountries() {
      try {
        const response = await fetch("countries.json");
        const data = await response.json();
        setCountries(data);
      } catch (error) {
        console.error("Error loading country data:", error);
      }
    }

    loadCountries();
  }, []);

  const fetchLocationInfo = (countryCode) => {
    if (!countryCode) {
      setLocationInfo(null);
      return;
    }

    setLoading(true);
    setLocationInfo(null);

    setTimeout(() => {
      const locationData = {
        US: {
          90210: {
            country: "United States",
            "country abbreviation": "US",
            places: [
              {
                "place name": "Beverly Hills",
                longitude: "-118.4065",
                state: "California",
                "state abbreviation": "CA",
                latitude: "34.0901",
              },
            ],
          },
        },
        CA: {
          M5A: {
            country: "Canada",
            "country abbreviation": "CA",
            places: [
              {
                "place name": "Toronto",
                longitude: "-79.3832",
                state: "Ontario",
                "state abbreviation": "ON",
                latitude: "43.6532",
              },
            ],
          },
        },
        DE: {
          10115: {
            country: "Germany",
            "country abbreviation": "DE",
            places: [
              {
                "place name": "Berlin",
                longitude: "13.4050",
                state: "Berlin",
                "state abbreviation": "BE",
                latitude: "52.5200",
              },
            ],
          },
        },
        FR: {
          75001: {
            country: "France",
            "country abbreviation": "FR",
            places: [
              {
                "place name": "Paris",
                longitude: "2.3522",
                state: "Île-de-France",
                "state abbreviation": "IDF",
                latitude: "48.8566",
              },
            ],
          },
        },
        JP: {
          "100-0001": {
            country: "Japan",
            "country abbreviation": "JP",
            places: [
              {
                "place name": "Tokyo",
                longitude: "139.6917",
                state: "Tokyo",
                "state abbreviation": "13",
                latitude: "35.6762",
              },
            ],
          },
        },
      };

      const data = locationData[countryCode];

      setLoading(false);
      setLocationInfo(data ? JSON.stringify(data, null, 2) : "No data found.");
    }, 1000); // Simulate delay
  };

  return (
    <div className="container py-5">
      <h1 className="mb-4">Select Country</h1>

      <div className="form-group">
        <label htmlFor="countrySelect">Country:</label>
        <select
          id="countrySelect"
          className="form-control"
          value={selectedCountry}
          onChange={(e) => {
            setSelectedCountry(e.target.value);
            fetchLocationInfo(e.target.value);
          }}
        >
          <option value="">Select a country</option>
          {countries.map((country) => (
            <option key={country.code} value={country.code}>
              {country.name} ({country.code})
            </option>
          ))}
        </select>
      </div>

      {loading && (
        <div style={{ textAlign: "center" }}>
          <i
            className="fas fa-spinner fa-spin"
            style={{ fontSize: "30px" }}
          ></i>{" "}
          Loading...
        </div>
      )}

      {locationInfo && !loading && (
        <div id="locationInfo">
          <h3>Location Info:</h3>
          <pre>{locationInfo}</pre>
        </div>
      )}
    </div>
  );
};

export default CountryCodeDropdown;
